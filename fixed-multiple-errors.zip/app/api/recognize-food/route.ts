import OpenAI from "openai"
import { GoogleGenerativeAI } from "@google/generative-ai"

export async function POST(request: Request) {
  try {
    console.log("[v0] Starting food recognition")

    const modelProvider = request.headers.get("x-model-provider") || "openai"
    const openaiKey = request.headers.get("x-openai-api-key") || ""
    const geminiKey = request.headers.get("x-gemini-api-key") || ""

    console.log("[v0] Model provider:", modelProvider)
    console.log("[v0] Has OpenAI key:", !!openaiKey)
    console.log("[v0] Has Gemini key:", !!geminiKey)

    const { image } = await request.json()

    if (!image) {
      console.log("[v0] No image provided")
      return Response.json({ error: "No image provided" }, { status: 400 })
    }

    console.log("[v0] Image received, length:", image.length)

    if (modelProvider === "gemini") {
      console.log("[v0] Using Gemini model")

      if (!geminiKey) {
        console.log("[v0] Gemini key missing")
        return Response.json({ error: "Gemini API key is required. Please add it in Settings." }, { status: 401 })
      }

      const genAI = new GoogleGenerativeAI(geminiKey)
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" })

      // Convert base64 image to the format Gemini expects
      const base64Data = image.split(",")[1]
      const mimeType = image.split(";")[0].split(":")[1]

      console.log("[v0] Calling Gemini API")
      const result = await model.generateContent([
        {
          inlineData: {
            data: base64Data,
            mimeType: mimeType,
          },
        },
        "Analyze this image and identify all the food ingredients you can see. List them in a clear, comma-separated format. Only list the ingredients, nothing else. If you see prepared dishes, try to identify the main ingredients. Be specific but concise.",
      ])

      const text = result.response.text()
      console.log("[v0] Gemini response:", text)

      // Parse the ingredients from the response
      const ingredients = text
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item.length > 0)

      console.log("[v0] Parsed ingredients:", ingredients)
      return Response.json({ ingredients })
    } else {
      // OpenAI flow
      console.log("[v0] Using OpenAI model")

      if (!openaiKey) {
        console.log("[v0] OpenAI key missing")
        return Response.json({ error: "OpenAI API key is required. Please add it in Settings." }, { status: 401 })
      }

      try {
        console.log("[v0] Creating OpenAI client")
        const openai = new OpenAI({
          apiKey: openaiKey,
          dangerouslyAllowBrowser: true,
        })

        console.log("[v0] Preparing API request")
        console.log("[v0] Image format check:", image.substring(0, 50))

        console.log("[v0] Calling OpenAI API")
        const response = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "Analyze this image and identify all the food ingredients you can see. List them in a clear, comma-separated format. Only list the ingredients, nothing else. If you see prepared dishes, try to identify the main ingredients. Be specific but concise.",
                },
                {
                  type: "image_url",
                  image_url: {
                    url: image,
                  },
                },
              ],
            },
          ],
          max_tokens: 300,
        })

        console.log("[v0] OpenAI response received")
        console.log("[v0] Response structure:", JSON.stringify(response, null, 2))

        const text = response.choices?.[0]?.message?.content

        if (!text) {
          console.log("[v0] No content in OpenAI response")
          return Response.json({ error: "No response from OpenAI" }, { status: 500 })
        }

        console.log("[v0] OpenAI response text:", text)

        // Parse the ingredients from the response
        const ingredients = text
          .split(",")
          .map((item) => item.trim())
          .filter((item) => item.length > 0)

        console.log("[v0] Parsed ingredients:", ingredients)
        return Response.json({ ingredients })
      } catch (openaiError) {
        console.error("[v0] OpenAI specific error:", openaiError)
        console.error("[v0] Error details:", JSON.stringify(openaiError, null, 2))

        const errorMessage = openaiError instanceof Error ? openaiError.message : "Failed to call OpenAI API"
        return Response.json({ error: errorMessage }, { status: 500 })
      }
    }
  } catch (error) {
    console.error("[v0] General error recognizing food:", error)
    console.error("[v0] Error stack:", error instanceof Error ? error.stack : "No stack trace")

    return Response.json(
      {
        error: error instanceof Error ? error.message : "Failed to recognize food",
      },
      { status: 500 },
    )
  }
}
