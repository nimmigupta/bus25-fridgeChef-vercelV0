"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Upload, Camera, Clipboard, Loader2, X, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function ImageUpload() {
  const [dragActive, setDragActive] = useState(false)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [cameraMode, setCameraMode] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [pasteMode, setPasteMode] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const handlePasteEvent = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items
      if (!items) return

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith("image/")) {
          const blob = items[i].getAsFile()
          if (blob) {
            const reader = new FileReader()
            reader.onload = (event) => {
              setSelectedImage(event.target?.result as string)
              setPasteMode(false)
              toast({
                title: "Image Pasted",
                description: "Your image has been successfully pasted.",
              })
            }
            reader.readAsDataURL(blob)
          }
          e.preventDefault()
          break
        }
      }
    }

    document.addEventListener("paste", handlePasteEvent)
    return () => {
      document.removeEventListener("paste", handlePasteEvent)
    }
  }, [toast])

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  const handleFile = (file: File) => {
    if (file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handlePaste = async () => {
    try {
      // Try the Clipboard API first
      const clipboardItems = await navigator.clipboard.read()
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith("image/")) {
            const blob = await item.getType(type)
            const reader = new FileReader()
            reader.onload = (e) => {
              setSelectedImage(e.target?.result as string)
              toast({
                title: "Image Pasted",
                description: "Your image has been successfully pasted.",
              })
            }
            reader.readAsDataURL(blob)
            return
          }
        }
      }
      // No image found in clipboard
      toast({
        title: "No Image Found",
        description: "Please copy an image first, then try pasting again.",
        variant: "destructive",
      })
    } catch (err) {
      // Clipboard API blocked or failed, show paste instructions
      console.log("Clipboard API not available, showing paste instructions")
      setPasteMode(true)
      toast({
        title: "Use Keyboard to Paste",
        description: "Press Ctrl+V (Windows/Linux) or Cmd+V (Mac) to paste your image.",
      })
    }
  }

  const startCamera = async () => {
    setCameraError(null)

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      })
      setStream(mediaStream)
      setCameraMode(true)

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream
        }
      }, 100)
    } catch (err) {
      console.error("Failed to access camera:", err)

      let errorMessage = "Unable to access camera. "

      if (err instanceof Error) {
        if (err.name === "NotAllowedError" || err.message.includes("Permission")) {
          errorMessage +=
            "Camera permission was denied. Please allow camera access in your browser settings, or use the file upload option instead."
        } else if (err.name === "NotFoundError") {
          errorMessage += "No camera found on this device. Please use the file upload option."
        } else if (err.name === "NotReadableError") {
          errorMessage += "Camera is already in use by another application. Please close other apps and try again."
        } else {
          errorMessage += "Please try using the file upload option instead."
        }
      }

      setCameraError(errorMessage)

      toast({
        title: "Camera Access Failed",
        description: "You can still upload a photo using the file upload option.",
        variant: "destructive",
      })
    }
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(video, 0, 0)
        const imageData = canvas.toDataURL("image/jpeg")
        setSelectedImage(imageData)
        stopCamera()
      }
    }
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setCameraMode(false)
    setCameraError(null)
  }

  const handleAnalyze = async () => {
    if (!selectedImage) return

    console.log("[v0] Starting analysis")

    const modelProvider = localStorage.getItem("modelProvider") || "openai"
    const openaiKey = localStorage.getItem("openaiApiKey") || ""
    const geminiKey = localStorage.getItem("geminiApiKey") || ""

    console.log("[v0] Model provider:", modelProvider)
    console.log("[v0] Has OpenAI key:", !!openaiKey)
    console.log("[v0] Has Gemini key:", !!geminiKey)

    if (modelProvider === "openai" && !openaiKey) {
      console.log("[v0] OpenAI key missing, redirecting to settings")
      toast({
        title: "API Key Required",
        description: "Please add your OpenAI API key in Settings to use this feature.",
        variant: "destructive",
      })
      router.push("/settings")
      return
    }

    if (modelProvider === "gemini" && !geminiKey) {
      console.log("[v0] Gemini key missing, redirecting to settings")
      toast({
        title: "API Key Required",
        description: "Please add your Gemini API key in Settings to use this feature.",
        variant: "destructive",
      })
      router.push("/settings")
      return
    }

    setIsAnalyzing(true)
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "x-model-provider": modelProvider,
      }

      if (openaiKey) headers["x-openai-api-key"] = openaiKey
      if (geminiKey) headers["x-gemini-api-key"] = geminiKey

      console.log("[v0] Sending request to API")
      const response = await fetch("/api/recognize-food", {
        method: "POST",
        headers,
        body: JSON.stringify({ image: selectedImage }),
      })

      console.log("[v0] Response status:", response.status)

      if (response.status === 401) {
        const { error } = await response.json()
        console.log("[v0] Authentication error:", error)
        toast({
          title: "Authentication Error",
          description: error || "Invalid API key. Please check your settings.",
          variant: "destructive",
        })
        router.push("/settings")
        return
      }

      if (!response.ok) {
        const errorData = await response.json()
        console.log("[v0] Error response:", errorData)
        throw new Error(errorData.error || "Failed to analyze image")
      }

      const { ingredients } = await response.json()
      console.log("[v0] Received ingredients:", ingredients)

      sessionStorage.setItem("ingredients", JSON.stringify(ingredients))
      sessionStorage.setItem("ingredientImage", selectedImage)
      router.push("/recipes")
    } catch (error) {
      console.error("[v0] Error analyzing image:", error)
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to analyze image. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {cameraError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Camera Access Issue</AlertTitle>
          <AlertDescription className="mt-2 space-y-2">
            <p>{cameraError}</p>
            <div className="flex gap-2 mt-3">
              <Button size="sm" variant="outline" onClick={() => setCameraError(null)}>
                Dismiss
              </Button>
              <Button size="sm" onClick={() => fileInputRef.current?.click()}>
                Upload File Instead
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {pasteMode && (
        <Alert>
          <Clipboard className="h-4 w-4" />
          <AlertTitle>Ready to Paste</AlertTitle>
          <AlertDescription className="mt-2 space-y-2">
            <p>Copy an image, then press:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>
                <strong>Windows/Linux:</strong> Ctrl + V
              </li>
              <li>
                <strong>Mac:</strong> Cmd + V
              </li>
            </ul>
            <Button size="sm" variant="outline" onClick={() => setPasteMode(false)} className="mt-2">
              Cancel
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Card
        className={cn(
          "border-2 border-dashed transition-colors",
          dragActive ? "border-primary bg-primary/5" : "border-border",
          (selectedImage || cameraMode) && "border-solid",
          pasteMode && "border-primary bg-primary/5",
        )}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="p-8 md:p-12">
          {cameraMode ? (
            <div className="space-y-6">
              <div className="relative aspect-video rounded-lg overflow-hidden bg-black">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white"
                  onClick={stopCamera}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <div className="flex gap-3">
                <Button size="lg" className="flex-1" onClick={capturePhoto}>
                  <Camera className="h-5 w-5 mr-2" />
                  Capture Photo
                </Button>
                <Button size="lg" variant="outline" onClick={stopCamera}>
                  Cancel
                </Button>
              </div>
              <canvas ref={canvasRef} className="hidden" />
            </div>
          ) : selectedImage ? (
            <div className="space-y-6">
              <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                <img
                  src={selectedImage || "/placeholder.svg"}
                  alt="Selected food"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button size="lg" className="flex-1" onClick={handleAnalyze} disabled={isAnalyzing}>
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Ingredients"
                  )}
                </Button>
                <Button size="lg" variant="outline" onClick={() => setSelectedImage(null)} disabled={isAnalyzing}>
                  Clear
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
                  <Upload className="h-12 w-12 text-primary" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Upload Your Ingredients</h3>
                <p className="text-muted-foreground">Drag and drop an image, or choose from the options below</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Button
                  size="lg"
                  variant="outline"
                  className="h-auto py-4 flex-col gap-2 bg-transparent"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-6 w-6" />
                  <span>Upload File</span>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-auto py-4 flex-col gap-2 bg-transparent"
                  onClick={startCamera}
                >
                  <Camera className="h-6 w-6" />
                  <span>Take Photo</span>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-auto py-4 flex-col gap-2 bg-transparent"
                  onClick={handlePaste}
                >
                  <Clipboard className="h-6 w-6" />
                  <span>Paste Image</span>
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileInput} />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileInput}
      />
    </div>
  )
}
